$(document).ready(function () {

  $("slider")=getElementById('slider');
  $("div1")=getElementById('div1');
  $("div2")=getElementById('div2');

  $("div1").hide();
  $("div2").hide();

  tab=new Array[div1,div2]

  for (var i = 0; i < tab.length; i++) {
    tab[i]
  }
})
